//
//  FourthViewController.m
//  AutoLayoutStudy
//
//  Created by Zions Jen on 2021/10/4.
//

#import "FourthViewController.h"
#define dataArr @[@"年金险", @"意外险", @"寿险", @"医疗险", @"重疾险"]

@interface FourthViewController () <UIPickerViewDataSource, UIPickerViewDelegate>

@end

@implementation FourthViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)showPickerView {
    [UIView animateWithDuration:.35 animations:^{
        self->_pickerBGVi.transform = CGAffineTransformMakeTranslation(0, -CGRectGetHeight(self->_pickerBGVi.frame));
        self->_alphaBackgroundVi.alpha = .6f;
    }];
}

#pragma mark - UIButtonAction
- (IBAction)confirmBtnAction:(UIButton *)sender {
    NSString *contentStr = dataArr[[_pickerVi selectedRowInComponent:0]];
    _productTextField.text = contentStr;
    
    bool isPension = [contentStr isEqualToString:@"年金险"], isAccident = [contentStr isEqualToString:@"意外险"];
    _pensionLC.priority = isPension?UILayoutPriorityDefaultLow:998;
    _accidentLC.priority = isAccident?UILayoutPriorityDefaultLow:998;
    _allHideLC.priority = (!isPension && !isAccident)?999:UILayoutPriorityDefaultLow;

    [self closeBtnAction:sender];
}

- (IBAction)closeBtnAction:(id)sender {
    [UIView animateWithDuration:.35 animations:^{
        self->_alphaBackgroundVi.alpha = 0;
        self->_pickerBGVi.transform = CGAffineTransformIdentity;
    } completion:nil];
}

- (IBAction)radioBtnAction:(UIButton *)sender {
    if (sender.selected) return;
    sender.selected = !sender.selected;
    
    UIButton *paramBtn = sender == _radioBtn1?_radioBtn2:_radioBtn1;
    paramBtn.selected = !paramBtn.selected;
    
    _addBeneficiaryViHeight.priority = sender == _radioBtn2?UILayoutPriorityDefaultLow:999;
}

#pragma mark - UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return dataArr.count;
}

#pragma mark - UIPickerViewDelegate
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return dataArr[row];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    if (textField == _productTextField) {
        [self showPickerView];
        return NO;
    }
    return YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
