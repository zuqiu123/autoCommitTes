//
//  FirstViewController.m
//  AutoLayoutStudy
//
//  Created by Zions Jen on 2021/7/30.
//

#import "FirstViewController.h"
#import "SDAutoLayout.h"
#import "Masonry.h"

@interface FirstViewController ()
{
    UIButton *btn;
}

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    //举例：一个button，宽高120/44，屏幕水平/垂直皆居中
    
    btn = [[UIButton alloc] init];
    btn.backgroundColor = [UIColor orangeColor];
//    btn.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:btn];
    
    
    //布局方式：
//    [self commonLayout1];
}

- (void)commonLayout1 {
    
    //计算frame
    
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    btn.frame = CGRectMake((screenSize.width-120)/2, (screenSize.height-44)/2, 120, 44);
}

- (void)commonLayout2 {
    
    //autoLayout
    
    NSLayoutConstraint *layout1 = [NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:0];
    NSLayoutConstraint *layout2 = [NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterY multiplier:1 constant:0];
    NSLayoutConstraint *layout3 = [NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:120];
    NSLayoutConstraint *layout4 = [NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:44];
    [self.view addConstraints:@[layout1, layout2, layout3, layout4]];
}

- (void)commonLayout3 {
    
    //VFL
    
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    NSNumber *x = @((screenSize.width-120)/2), *y = @((screenSize.height-44)/2);
    // 添加水平方向的约束
    NSString *vfl1 = @"H:|-x-[btn(120)]-x-|";
    // 添加竖直方向的约束
    NSString *vfl2 = @"V:|-y-[btn(44)]-y-|";
    
    NSDictionary *views = NSDictionaryOfVariableBindings(btn);
    NSDictionary *metrics1 = NSDictionaryOfVariableBindings(x);
    NSDictionary *metrics2 = NSDictionaryOfVariableBindings(y);
    NSArray *constraints1 = [NSLayoutConstraint constraintsWithVisualFormat:vfl1 options:kNilOptions metrics:metrics1 views:views];
    [self.view addConstraints:constraints1];
    
    NSArray *constraints2 = [NSLayoutConstraint constraintsWithVisualFormat:vfl2 options:kNilOptions metrics:metrics2 views:views];
    [self.view addConstraints:constraints2];
}

- (void)commonLayout4 {
    
    //SDAutoLayout
    
    btn.sd_layout
    .centerXEqualToView(self.view)
    .centerYEqualToView(self.view)
    .widthIs(120)
    .heightIs(44);
}

- (void)commonLayout5 {

    //Masonry
    
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(120);
        make.height.mas_equalTo(44);
        make.centerX.equalTo(self.view);
        make.centerY.equalTo(self.view);
    }];
}

- (void)commonLayout6 {
    
    //StoryBoard/xib
}





//1、计算frame
//2、autoLayout
//3、VFL
//4、SDAutoLayout
//5、Masonry
//6、StoryBoard/xib

@end
