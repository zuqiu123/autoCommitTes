//
//  UnWindViewController.m
//  AutoLayoutStudy
//
//  Created by Zions Jen on 2021/8/14.
//

#import "UnWindViewController.h"

@interface UnWindViewController ()

@end

@implementation UnWindViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)backToPage1:(UIStoryboardSegue *)segue {}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
