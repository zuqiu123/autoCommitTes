//
//  FourthViewController.h
//  AutoLayoutStudy
//
//  Created by Zions Jen on 2021/8/4.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FourthViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *alphaBackgroundVi;
@property (weak, nonatomic) IBOutlet UIView *pickerBGVi;
@property (weak, nonatomic) IBOutlet UIPickerView *pickerVi;
@property (weak, nonatomic) IBOutlet UITextField *productTextField;
@property (weak, nonatomic) IBOutlet UIButton *radioBtn1;
@property (weak, nonatomic) IBOutlet UIButton *radioBtn2;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *addBeneficiaryViHeight;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *pensionLC;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *accidentLC;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *allHideLC;

@end

NS_ASSUME_NONNULL_END
