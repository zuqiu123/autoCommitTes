//
//  SceneDelegate.h
//  AutoLayoutStudy
//
//  Created by Zions Jen on 2021/7/30.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

