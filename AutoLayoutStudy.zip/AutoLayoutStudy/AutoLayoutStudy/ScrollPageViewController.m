//
//  ScrollPageViewController.m
//  AutoLayoutStudy
//
//  Created by Zions Jen on 2021/9/8.
//

#import "ScrollPageViewController.h"
#define XXXX [UIScreen mainScreen].bounds.size.width

@interface ScrollPageViewController () <UIScrollViewDelegate>

@end

@implementation ScrollPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

#pragma mark - UIButtonAction
- (IBAction)optionBtnAction:(UIButton *)sender {
    if (sender.selected) return;
    [self.scrollVi setContentOffset:CGPointMake((CGRectGetMidX(sender.frame)+2)<XXXX/2?0:(CGRectGetMidX(sender.frame)-2)>XXXX/2?XXXX*2:XXXX, 0) animated:YES];
    for (UIButton *btn in sender.superview.subviews) {
        if ([btn isKindOfClass:[UIButton class]]) {
            btn.selected = NO;
        }
    }
    sender.selected = YES;
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == self.scrollVi && scrollView.contentSize.width > 0) {
        self.moveLineVi.center = CGPointMake(XXXX*scrollView.contentOffset.x/scrollView.contentSize.width*3/4 + XXXX/4, self.moveLineVi.center.y);
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    if (scrollView == self.scrollVi) {
        for (UIView *vi in self.moveLineVi.superview.subviews) {
            if ([vi isKindOfClass:[UIButton class]]) {
                UIButton *tempBtn = (UIButton *)vi;
                tempBtn.selected = CGRectGetMidX(self.moveLineVi.frame)-2<CGRectGetMidX(vi.frame) && CGRectGetMidX(self.moveLineVi.frame)+2>CGRectGetMidX(vi.frame);
            }
        }
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
