//
//  StaticCellViewController.m
//  AutoLayoutStudy
//
//  Created by Zions Jen on 2021/9/8.
//

#import "StaticCellViewController.h"

@interface StaticCellViewController () <UITableViewDelegate>

@end

@implementation StaticCellViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.hideLC.constant = -[UIScreen mainScreen].bounds.size.width/2;
}

#pragma mark - UIButtonAction
- (IBAction)optionsBtnAction:(UIButton *)sender {
    [UIView animateWithDuration:.35 animations:^{
        self.alphaBackgroundVi.alpha = .6f;
        self.backVi.transform = CGAffineTransformMakeTranslation(CGRectGetWidth(self.backVi.frame), 0);
    }];
}

- (IBAction)closeBtnAction:(id)sender {
    if (CGAffineTransformIsIdentity(self.backVi.transform)) return;
    [UIView animateWithDuration:.35 animations:^{
        self.alphaBackgroundVi.alpha = 0;
        self.backVi.transform = CGAffineTransformIdentity;
    }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
