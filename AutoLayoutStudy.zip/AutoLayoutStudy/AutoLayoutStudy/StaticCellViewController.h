//
//  StaticCellViewController.h
//  AutoLayoutStudy
//
//  Created by Zions Jen on 2021/9/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface StaticCellViewController : UIViewController

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *hideLC;
@property (strong, nonatomic) IBOutlet UIView *alphaBackgroundVi;
@property (strong, nonatomic) IBOutlet UIView *backVi;

@end

NS_ASSUME_NONNULL_END
