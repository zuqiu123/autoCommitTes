//
//  SecondViewController.h
//  AutoLayoutStudy
//
//  Created by Zions Jen on 2021/7/30.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SecondViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *vflVi1;
@property (weak, nonatomic) IBOutlet UIView *vflVi2;

@end

NS_ASSUME_NONNULL_END
