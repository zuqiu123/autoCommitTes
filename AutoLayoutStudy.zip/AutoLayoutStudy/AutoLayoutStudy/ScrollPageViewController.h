//
//  ScrollPageViewController.h
//  AutoLayoutStudy
//
//  Created by Zions Jen on 2021/9/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ScrollPageViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIView *moveLineVi;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollVi;

@end

NS_ASSUME_NONNULL_END
